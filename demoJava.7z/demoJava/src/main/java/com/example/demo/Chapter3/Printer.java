package com.example.demo.Chapter3;

public interface Printer {
    public String print(String text);
}

package com.example.demo.Chapter3.BakeryStore;

public interface BakeStore {

    public Cake bakeACake();

    public void setOven(Oven myOven);

    public Oven getOven();

}

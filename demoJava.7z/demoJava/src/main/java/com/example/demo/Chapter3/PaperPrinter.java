package com.example.demo.Chapter3;

public class PaperPrinter implements Printer{
    @Override
    public String print(String text) {
        return text;
    }
}

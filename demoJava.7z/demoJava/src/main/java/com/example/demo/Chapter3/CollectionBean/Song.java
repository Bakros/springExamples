package com.example.demo.Chapter3.CollectionBean;

public class Song {
    private String title;

    public Song(String title) {
        this.title = title;
    }
    public String getTitle() {
        return title;
    }
}

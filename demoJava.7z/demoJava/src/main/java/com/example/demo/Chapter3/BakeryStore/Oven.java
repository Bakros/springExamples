package com.example.demo.Chapter3.BakeryStore;

public interface Oven {
    public Cake bakeALemonCake();
}

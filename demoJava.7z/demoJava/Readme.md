<h3>Example Chapter 3 from Pro Spring 6 <br/>
package com.example.demo.Chapter3</h3>

Package Autowired <br/>
Title > Using Constructor Injection
This is an example of how @Autowired is not need it 
when there is only one constructor.
<br>
Also it shows that @Autowired is mandatory on Setter Inyection.
Otherwise the setter is not executed and the Bean is never inyected.


Pendiente> 
Page 59 @Resource to replace @Autowired.
Page 89 > Injection and ApplicationContext Nesting - No entender.




